<?php
/**
 * Images printed without any alt attribute in Elementor content (for example the
 * logo the ThemeREX "background text" marquee repeats between its words) get an
 * empty alt, which marks them as decorative. Screen readers then skip them instead
 * of reading the file name, and accessibility audits stop flagging them. Images
 * that have an alt, empty or not, are left alone.
 *
 * @package AvixWidgets
 */

namespace AvixWidgets\SEO;

defined( 'ABSPATH' ) || exit;

final class Image_Alt {

	public static function init(): void {
		add_filter( 'elementor/frontend/the_content', array( __CLASS__, 'add_missing_alt' ), 20 );
	}

	/**
	 * alt="" on every <img> that has no alt attribute.
	 *
	 * @param mixed $html Rendered builder content.
	 * @return mixed
	 */
	public static function add_missing_alt( $html ) {
		if ( ! is_string( $html ) || false === stripos( $html, '<img' ) ) {
			return $html;
		}
		return (string) preg_replace( '/<img\b(?![^>]*\balt\s*=)/i', '<img alt=""', $html );
	}
}
